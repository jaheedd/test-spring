package com.json.helper;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LogRequestIDInterceptor extends HandlerInterceptorAdapter {
	private static final String TOKEN_REQ_ID = "REQ_ID";
	/**
	 * This method will invoke for all api's start with /
	 * it will generate Unique hexa decimal id and putting 
	 * it in thread context which will include in all logs.
	 * 
	 */
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws Exception {
		String rivetReqId = request.getHeader(TOKEN_REQ_ID);
		if(rivetReqId == null){
			MDC.put(TOKEN_REQ_ID, UUID.randomUUID().toString());
		}else{
			MDC.put(TOKEN_REQ_ID, rivetReqId);
		}
		response.addHeader(TOKEN_REQ_ID, MDC.get(TOKEN_REQ_ID));
  		return true;
	}
}

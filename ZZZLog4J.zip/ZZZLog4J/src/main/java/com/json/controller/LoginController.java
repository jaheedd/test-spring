package com.json.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import com.json.bean.Emp;
import com.json.bean.EmployeeDto;
import com.json.bean.InsertRecord;
import com.json.bean.ListUser;
import com.json.bean.LoginListUsers;
import com.json.bean.LoginRequest;
import com.json.bean.LoginResponse;
import com.json.service.LoginService;

@Controller
public class LoginController {
	private static final Logger logger = Logger.getLogger(LoginController.class);
	@Autowired
	protected LoginService loginService;
	
	
	public static void main(String[] args){
		PropertyConfigurator.configure("log.properties");

	    logger.info("main method");	
	}
	
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/botnewuser")
	@ResponseBody
	public LoginResponse getBotNewUser(@RequestBody LoginRequest botNewUserRequest)
	{
		logger.info("in controlerr getting the req");
		LoginResponse newUserResponse = loginService.getBotNewUser(botNewUserRequest);
		return newUserResponse;
	}
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	@ResponseBody
	public List<LoginListUsers> usersList() {
		logger.info("in controller class impln");
		List<LoginListUsers> list = loginService.getList();
		System.out.println(list.get(0).getEmail());
		System.out.println(list.get(0).getPhone());
		return list;
	}
	@RequestMapping(method = RequestMethod.POST, value = "/insert")
	@ResponseBody
	public List<InsertRecord> insert(@RequestBody InsertRecord insert)
	{
		List<InsertRecord> response = loginService.insertRecord(insert);
		return response;
	}
	@RequestMapping(value = "/list1", method = RequestMethod.GET)
	@ResponseBody
	public List<ListUser> List() {

		logger.info("inside conteoller");
     List<ListUser> list = loginService.getList1();
	return list;
	}
	@RequestMapping(method = RequestMethod.POST, value = "/record")
	@ResponseBody
	public LoginResponse recordInsert(@RequestBody Emp emp)
	{
		LoginResponse response = loginService.record(emp);
		return response;
	}

	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public List<EmployeeDto> addEmployee(@RequestBody EmployeeDto emp){
		logger.info("passing employee dto object");
		System.out.println("calling add employee method"+emp.getEmail());
		List<EmployeeDto> e = loginService.addEmployee(emp);
		return e;
	}

}


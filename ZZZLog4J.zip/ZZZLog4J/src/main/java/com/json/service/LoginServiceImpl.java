package com.json.service;

import java.util.ArrayList;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.json.bean.Emails;
import com.json.bean.Emp;
import com.json.bean.EmployeeDto;
import com.json.bean.InsertRecord;
import com.json.bean.ListUser;
import com.json.bean.LoginListUsers;
import com.json.bean.LoginRequest;
import com.json.bean.LoginResponse;
import com.json.bean.Phones;
import com.json.dao.LoginDao;
import com.json.entity.Employee;

@Service
public class LoginServiceImpl implements LoginService{
	private static final Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class.getName());
	@Autowired
	protected LoginDao loginDao;

	public LoginResponse getBotNewUser(LoginRequest botNewUserRequest) {
		logger.info("getting request to service");
		int newInsert = 0;
		LoginResponse botNewUser = new LoginResponse();
		System.out.println(botNewUserRequest.getName());
		System.out.println(botNewUserRequest.getPassword());
		System.out.println(botNewUserRequest.getPhone());
		if(botNewUserRequest.getPhone().matches("\\d+") && botNewUserRequest.getPhone().trim().length()==10)
		{
			newInsert = loginDao.getBotNewUser(botNewUserRequest);
			System.out.println(newInsert);
			if(newInsert>0){
				logger.info("inside check");
				if("pavani".equalsIgnoreCase(botNewUserRequest.getName()) && 
						"pavani123"
						.equalsIgnoreCase(botNewUserRequest.getPassword())){
					System.out.println("coming");
					botNewUser.setStatus("sucess");
					botNewUser.setMessage("u are valid user");
				}else{
					botNewUser.setStatus("faild");
					botNewUser.setMessage("u are a invalid user");
				}
			}
		}
		return botNewUser;

	}

	public List<LoginListUsers> getList() {
		 logger.info("in service implimentation");
		List<LoginListUsers> listusers = new ArrayList<LoginListUsers>();
		try{

			List<LoginListUsers[]> list = loginDao.getList(); 
            if(list != null){
				if(list .size() > 0){

					for(Object[] obj : list ){
						List<String> elist = new ArrayList<String>();
						List<String> plist = new ArrayList<String>();
						LoginListUsers l1 = new LoginListUsers();
						if(obj[0] != null){
                         	l1.setId((Integer)obj[0]);
						}
						if(obj[1] != null){
							l1.setName((String) obj[1]);
						}
						if(obj[2] != null){
							l1.setPassword((String) obj[2]);
						}
						if(obj[3] != null){

							String emails = (String) obj[3];	
							elist.add(emails);
						}
						if(obj[4] != null){
							String phones = (String)obj[4];  
							plist.add(phones);
						}
						if(obj[5]!=null){
							String emails1 = (String) obj[5];
							elist.add(emails1);
						}
						if(obj[6]!=null){
							String emails2 = (String) obj[6];
							elist.add(emails2);
						}

						if(obj[7] != null){
							String phones1 = (String)obj[7];  
							plist.add(phones1);
						}
						l1.setPhone(plist);
						l1.setEmail(elist);
						listusers.add(l1);

					}

				}
			}
		}
		catch(Exception e){
			logger.error("Exception"+e);
		}
		return listusers;
	}
	public List<InsertRecord> insertRecord(InsertRecord insert)
	{	
		List<InsertRecord> listusers1 = new ArrayList<InsertRecord>();
		try{
			List<Object[]> list = loginDao.insertRecord(insert);

			if(list != null && list .size() > 0){

				for(Object[] obj : list ){
					String[] e=new String[3];
					String[] p=new String[2];
					InsertRecord i1 = new InsertRecord();
					if(obj[0] != null){

						i1.setId((Integer)obj[0]);
					}
					if(obj[1] != null){
						i1.setName((String) obj[1]);
					}
					if(obj[2] != null){

						String email = (String) obj[2];	
						e[0]=email;
					}
					if(obj[3] != null){
						String phone = (String)obj[3];  
						p[0]=phone;
					}
					if(obj[4]!=null){
						String email1 = (String) obj[4];
						e[1]=email1;
					}
					if(obj[5]!=null){
						String email2 = (String) obj[5];
						e[2]=email2;
					}

					if(obj[6] != null){
						String phone1 = (String) obj[6];  
						p[1]=phone1;
					}
					i1.setPhones(p);
					i1.setEmails(e);


					listusers1.add(i1);	
			}
		}

	}
	catch(Exception e){
	logger.error("Exception"+e);
	}

	return listusers1;	
}
	public List<ListUser> getList1() {
		List<ListUser> listusers = new ArrayList<ListUser>();
		try{

			List<ListUser[]> list = loginDao.getList1(); 
			System.out.println("in service implimentation  "+list.size());
			if(list != null && list.size() > 0){
				
				Emails email=new Emails();
				Phones phone=new Phones(); 
				
				
					for(Object[] obj : list ){
						ListUser l1 = new ListUser();
						if(obj[0] != null){

							l1.setId((Integer)obj[0]);
						}
						if(obj[1] != null){
							l1.setName((String) obj[1]);
						}
						if(obj[2]!=null){
							email.setEmail((String) obj[2]);
						}
						if(obj[3] != null){
							
							phone.setPhone((String) obj[3]);
			    		}
						
						if(obj[4]!=null){
							email.setEmail1((String) obj[4]);
						}
						if(obj[5] != null){
								phone.setPhone1((String) obj[5]);
							
						}
						l1.setPhones(phone);
						l1.setEmails(email);
						listusers.add(l1);
					}
				}
			}
		catch(Exception e){
			logger.error("Exception"+e);
		}
		return listusers;
	}
	public LoginResponse record(Emp emp)
	{
		int rec = 0;
		LoginResponse response = new LoginResponse();
			rec = loginDao.record(emp);
		if(rec>0){
			response.setStatus("sucess");
			response.setMessage("record is inserted");
			}
		else{
			response.setStatus("faild");
			response.setMessage("record is not inserted");	
		}
		
		return response;		
}
	
	public List<EmployeeDto> addEmployee(EmployeeDto emp) {
		logger.info("adding employee record to employee pojo");
	    System.out.println("adding data in service"+emp.getDesignation());
	    List<EmployeeDto> dtoList = new ArrayList<EmployeeDto>();
	    Employee employee = new Employee();
    	System.out.println(emp.getfName());
         employee.setfName(emp.getfName());
         employee.setlName(emp.getlName());
         employee.setEmail(emp.getEmail());
         employee.setDesignation(emp.getDesignation());
         employee.setPhoneno(emp.getPhoneno());
         String s = null;
	    try{
	    	
	    	List<Object[]> list =loginDao.addEmployee(employee);
	    
	   if(list != null && list.size() > 0){
	    
	    
	     for(Object[] obj:list){
	        EmployeeDto e = new EmployeeDto();
	        if(obj[0] != null){
             	e.setEmpid((Integer)obj[0]);
			}
			if(obj[1] != null){
				e.setfName((String) obj[1]);
			}
			if(obj[2] != null){
				e.setlName((String) obj[2]);
			}
			if(obj[3] != null){
              e.setEmail((String) obj[3] );
			}
			if(obj[4] != null){
				e.setDesignation((String) obj[4] );
			}
			if(obj[5]!=null){
				e.setPhoneno((String) obj[5]);
			}
			
	       dtoList.add(e);
	  }
	    
	 }
 }
	 catch(Exception e){
			logger.error("Exception"+ e);
		}
	  
	  return dtoList;
	}
}
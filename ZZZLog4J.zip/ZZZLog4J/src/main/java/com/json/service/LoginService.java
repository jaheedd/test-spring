package com.json.service;


import java.util.List;

import com.json.bean.Emp;
import com.json.bean.EmployeeDto;
import com.json.bean.InsertRecord;
import com.json.bean.ListUser;
import com.json.bean.LoginListUsers;
import com.json.bean.LoginRequest;
import com.json.bean.LoginResponse;
import com.json.entity.Employee;

public interface LoginService {
	LoginResponse getBotNewUser(LoginRequest botNewUserRequest);
	public List<LoginListUsers>  getList();
	public List<InsertRecord> insertRecord(InsertRecord insert);
	public List<ListUser> getList1();
    LoginResponse record(Emp emp);
    public List<EmployeeDto> addEmployee(EmployeeDto emp);
}

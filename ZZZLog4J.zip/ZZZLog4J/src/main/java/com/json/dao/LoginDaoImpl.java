package com.json.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.json.bean.Address;
import com.json.bean.Emp;
import com.json.bean.EmployeeDto;
import com.json.bean.InsertRecord;
import com.json.bean.ListUser;
import com.json.bean.LoginListUsers;
import com.json.bean.LoginRequest;
import com.json.entity.Employee;
import com.json.service.LoginServiceImpl;

@Repository("LoginDao")
@Transactional
@EnableTransactionManagement
public class LoginDaoImpl implements LoginDao {
	private static final Logger logger = LoggerFactory.getLogger(LoginDaoImpl.class.getName());
	private SessionFactory dbsessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.dbsessionFactory = sessionFactory;
	}

	public int getBotNewUser(LoginRequest botNewUserRequest) {
		Session session = null;
		Transaction transaction = null;
       logger.info("inside dao gerrting request");
		int emailcheck = 0;
		int insertOwner = 0;
		try {
			session = dbsessionFactory.openSession();
			transaction = session.beginTransaction();
			Query query1 = session.createSQLQuery(
					"select exists(select phone from NewUser where phone='" + botNewUserRequest.getPhone() + "')");
			BigInteger email = (BigInteger) query1.uniqueResult();
			emailcheck = email.intValue();

			if (emailcheck == 0) {
				Query query2 = session.createSQLQuery("INSERT INTO NewUser(name,password,email,phone)" + " VALUES('"
						+ botNewUserRequest.getName() + "','" + botNewUserRequest.getPassword() + "','"
						+ botNewUserRequest.getEmail() + "','" + botNewUserRequest.getPhone() + "'");
				insertOwner = query2.executeUpdate();
				transaction.commit();
			} else {
				insertOwner = emailcheck;
			}

		} catch (Exception e) {
			transaction.rollback();
        logger.error("Exception"+ e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return insertOwner;
	}

	public List<LoginListUsers[]> getList() {
		Session session = null;
		Transaction transaction = null;
		List<LoginListUsers[]> list = null;
		try {
			logger.info("inside daoimpl getting list");
			session = dbsessionFactory.openSession();
			Query query = session.createSQLQuery("SELECT * FROM NewUser");
			list = query.list();
		} catch (DataAccessException e) {
			logger.error("Exception"+e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list;
	}

	public List<Object[]> insertRecord(InsertRecord insert) {
		logger.info("inside inset method");
		Session session = null;
		Transaction transaction = null;
		int id = 0;
		int record = 0;
		List<Object[]> record1 = null;
		int rec = 0;
		try {
			if (id == 0) {
				System.out.println("inside if ");
				session = dbsessionFactory.openSession();
				transaction = session.beginTransaction();
				String[] em = insert.getEmails();
				String email1 = null;
				String email2 = null;
				String email3 = null;

				if (em.length == 1) {
					email1 = em[0];
				}
				if (em.length == 2) {
					email1 = em[0];
					email2 = em[1];
				}
				if (em.length == 3) {
					email1 = em[0];
					email2 = em[1];
					email3 = em[2];
				}

				String[] ph = insert.getPhones();
				String phone = null;
				String phone1 = null;
				if (ph.length == 1) {
					phone = ph[0];

				}
				if (ph.length == 2) {
					phone = ph[0];
					phone1 = ph[1];
				}
				Query query = session
						.createSQLQuery("INSERT INTO NewUser(name,password,email,phone,email1,email2,phone1) "
								+ " VALUES('" + insert.getName() + "','" + insert.getPassword() + "','" + email1 + "','"
								+ phone + "','" + email2 + "','" + email3 + "','" + phone1 + "')");
				record = query.executeUpdate();
				System.out.println(record);

				logger.info("after insert");

				Query query1 = session.createSQLQuery("select max(id) from NewUser");
				Integer id1 = (Integer) query1.uniqueResult();
				id1 = id1.intValue();
				System.out.println(id1);
				if (record > 0) {
					Query query2 = session.createSQLQuery(
							"select id,name,email,phone,email1,phone1 from NewUser where id='" + id1 + "'");
					record1 = query2.list();
					transaction.commit();
				}
			}
		} catch (Exception e) {

			logger.error("Exception"+e);;
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return record1;
	}

	public List<ListUser[]> getList1() {
		Session session = null;
        List<ListUser[]> list = null;
		try {
          session = dbsessionFactory.openSession();
			Query query = session.createSQLQuery(
					"SELECT id,name,email,phone,email1,phone1 FROM NewUser WHERE id in(SELECT MAX(id) AS max_new_user_id FROM NewUser)");
			list = query.list();
		} catch (DataAccessException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list;
	}

	public int record(Emp emp) {
		logger.info("inserting and getting the record");
		Session session = null;
		int empid = 0;
		int record = 0, record1 = 0;
		List<Object[]> list = null;
		try {
			session = dbsessionFactory.openSession();

			Query query = session.createSQLQuery("select empid,name From emp where name='pavani'");
			list = query.list();
			System.out.println(list.size());

			if (list != null && !list.isEmpty()) {
				System.out.println("ifffffffffffff");
				empid = (Integer) list.get(0)[1];

			} else {
				System.out.println("else part");
				Query query1 = session.createSQLQuery("INSERT INTO emp(name,age,salary) " + " VALUES('" + emp.getName()
						+ "','" + emp.getAge() + "','" + emp.getSalary() + "')");
				record = query1.executeUpdate();
				Query query2 = session.createSQLQuery("select max(empid) from emp");
				empid = (Integer) query2.uniqueResult();
			}

			if (list.size() >= 0 && empid > 0) {
				for (int i = 0; i < emp.getAddress().size(); i++) {
					Query query3 = session.createSQLQuery("INSERT INTO address(empid,address) " + " VALUES('" + empid
							+ "','" + emp.getAddress().get(i).getAdd() + "')");
					record1 = query3.executeUpdate();
				}
				System.out.println(record1);

			}
		} catch (Exception e) {

			logger.error("Exception"+e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return record1;
	}

	public List<Object[]> addEmployee(Employee employee) {
		logger.info("inserting the record using hibernet query methods");
		Session session = null;
		String s = null;
		List<Object[]> list = null;
		try {
			session = dbsessionFactory.getCurrentSession();
			
		int id= (Integer) session.save(employee);
			
			s = "s";
			System.out.println(id);
			if (id > 0) {
				Query query = session.createSQLQuery("SELECT * FROM employee");
				list = query.list();
				System.out.println(list.size());
			}
			
		} catch (Exception e) {
			logger.error("Exception"+e);
		}
		return list;
	}
}

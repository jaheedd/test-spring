package com.json.bean;

import java.util.List;

public class InsertRecord {
private int id;
private String name;
private String password;
private String[] emails;
private String[] phones;
public String[] getEmails() {
	return emails;
}
public void setEmails(String[] emails) {
	this.emails = emails;
}
public String[] getPhones() {
	return phones;
}
public void setPhones(String[] phones) {
	this.phones = phones;
}



public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}

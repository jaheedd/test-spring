package com.json.bean;

public class Emails {
private String email;
private String email1;

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getEmail1() {
	return email1;
}
public void setEmail1(String email1) {
	this.email1 = email1;
}


}

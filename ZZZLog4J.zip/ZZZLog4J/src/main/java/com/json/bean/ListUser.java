package com.json.bean;



public class ListUser {
private int id;
private String name;
private  Emails emails;
private Phones phones;
public Emails getEmails() {
	return emails;
}
public void setEmails(Emails emails) {
	this.emails = emails;
}
public Phones getPhones() {
	return phones;
}
public void setPhones(Phones phones) {
	this.phones = phones;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}



}
